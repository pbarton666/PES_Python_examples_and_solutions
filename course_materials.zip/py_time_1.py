#py_time_1.py

from datetime import datetime
d=datetime.now()
print(d)
print("the hour is: {}\n".format(d.hour))
print("the year is: {}\n".format(d.year))

