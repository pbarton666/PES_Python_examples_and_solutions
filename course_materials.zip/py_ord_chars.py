#ord_chars.py
for i in range(33, 36):   #yes, I'm cheating - I already know it's 34
	print (i, chr(i))
	
QUOTE=chr(34)
print("I'm a double quote:  {}".format(QUOTE))


