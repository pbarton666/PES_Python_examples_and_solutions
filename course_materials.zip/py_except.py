
#py_except.py
try:
	assert False
except AssertionError:
	print("Sorry, pal")
print("I'm gonna keep running.")	