#py_logging_secondary.py
import logging
import py_logging_main

#from main import logger_object
logging.getLogger("logger")
logging.debug("secondary here")

