#py_unit_4_code.py
def add_numbers(first, second):
	return first + second