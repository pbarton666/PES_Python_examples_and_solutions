#solution_python1_chapter02_hello.py

"""Chapter 2 solution - how to say hello"""

#single lines
print("Hello Pythonic World")
print('Howdy from Python')

#span several lines (the replace() gets rid of line breaks)
print("""Hello
from
the
interpreter.""".replace('\n', ' '))

greeting = \
"""
Python
says
hi!
"""
print(greeting)
		 