#py_list_comp_1.py

print([str(x)+"!" for x in [y for y in range(10)]])

