#py_sequence_survey.py

the_string = "strings are sequences with an encoding"
the_bytes = bytearray(the_string, encoding='UTF-8')
the_range = range(10)
the_list = list(range(10))
the_tuple = tuple(range(10))

print("String      : ", the_string)
print("Bytes       : ", the_bytes)
print("List        : ", the_list)
print("Tuple       : ", the_tuple)

