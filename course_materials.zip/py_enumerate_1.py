#py_enumerate_1.py

fruits=('apple', 'banana', 'kiwi')
for snack_and_index in enumerate(fruits):
    print(snack_and_index)


