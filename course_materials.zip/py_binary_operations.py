#py_binary_operations.py	

mybin_1000=bin(1000)
print("mybin_1000: {}".format(mybin_1000))

print("mmybin_1000 shifted left: {}".format(bin(1000<<3)))
print("mmybin_1000 shifted right: {}".format(bin(1000>>5)))

