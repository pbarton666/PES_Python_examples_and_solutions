#py_gui.py
"gui basics"

from tkinter import *
class Application(Frame):
    pass

root = Tk()
app = Application(master=root)
app.mainloop()
	



